20203.03
This version changed the terminology in metamodel of hazard table.
The purpose is to in compliance with the thesis.

The change is:
Hazard log-> hazard table
control measure -> safety measure

The changed docs:
hazardlog metamodel
eol query file