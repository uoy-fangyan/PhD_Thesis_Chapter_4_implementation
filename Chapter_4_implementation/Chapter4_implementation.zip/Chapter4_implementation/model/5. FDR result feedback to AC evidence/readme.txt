2021.7.21

this step has not been implemented because LRE doesn't support FDR checking currently.
I need to fix LRE RC models first to successfully run FDR
Then I can have the checking result for generate evidence models

When run configuration, only one emf model will be used: SACM_AC, both load and store.
The key is to identify the evidence model and replace it with the model generated based on FDR result.