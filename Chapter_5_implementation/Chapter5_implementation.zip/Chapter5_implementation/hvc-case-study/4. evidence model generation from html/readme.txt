for this step 4, I only create evidence models for spec3
The reason is that the first 2 assertions are not running successfully in FDR at the moment
I need to trouble shooting first

 